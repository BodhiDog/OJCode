#include <iostream>
#include <string>
using namespace std;

int main()
{
	// ifstream ifs("test.txt"); // 改成你要打开的文件
	// streambuf *old_buffer = cin.rdbuf(ifs.rdbuf());

	// string read;
	// while (cin >> read) // 逐词读取方法一
	// {
	// }

	// cin.rdbuf(old_buffer); // 修复buffer
	return 0;
}